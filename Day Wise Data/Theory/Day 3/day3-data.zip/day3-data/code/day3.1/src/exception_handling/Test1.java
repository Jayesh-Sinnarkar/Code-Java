package exception_handling;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter join date (day-mon-yr)");
		Date d1 = parseDate(sc.next());
		System.out.println("Parsed date "+d1);
		sc.close();
		System.out.println("main cntd....");
	}

	// add a method for parsing from string --> Date
	private static Date parseDate(String s) {
		try {
			// How to Parse(convert) String --> Date ?
			// 1. Create SDF instance
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			return sdf.parse(s);// javac forces handling of chked exc
		} catch (ParseException e) {
			System.out.println("method level catch "+e);
		}
		System.out.println("invalid date ....");
		return null;
	}

}
