package utils;

import custom_exceptions.SpeedOutOfRangeException;

public class ValidationRules {
	public static final int MIN_SPEED;
	public static final int MAX_SPEED;
	static {
		MIN_SPEED=40;
		MAX_SPEED=80;
	}
//add a static method to validate speed
	public static void validateVehicleSpeed(int speed)  throws SpeedOutOfRangeException 
	{
		if(speed < MIN_SPEED)
			throw new SpeedOutOfRangeException("Too Slow !!!!!");
		if (speed > MAX_SPEED)
			throw new SpeedOutOfRangeException("Too fast ! FATAL !!!!!!");
		//=> speed within range
		System.out.println("speed within range!");
	}
}
