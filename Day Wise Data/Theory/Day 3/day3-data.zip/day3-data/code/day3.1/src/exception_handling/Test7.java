package exception_handling;

import java.util.Scanner;

public class Test7 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your age : int");
			System.out.println("Age " + sc.nextInt());
			System.out.println("end of try...");
		} // sc.close() : AutoCloseable i/f
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("main over");

	}

}
