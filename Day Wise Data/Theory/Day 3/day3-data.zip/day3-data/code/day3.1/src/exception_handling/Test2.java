package exception_handling;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) /* throws ParseException */ {

		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter join date (day-mon-yr)");
			Date d1 = parseDate(sc.next());
			System.out.println("Parsed date " + d1);
		} catch (Exception e) {
			System.out.println(e);
		}
		sc.close();
		System.out.println("main cntd....");
	}

	// add a method for parsing from string --> Date
	private static Date parseDate(String s) throws ParseException {

		// How to Parse(convert) String --> Date ?
		// 1. Create SDF instance
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		return sdf.parse(s);// javac forces handling of chked exc
	}

}
