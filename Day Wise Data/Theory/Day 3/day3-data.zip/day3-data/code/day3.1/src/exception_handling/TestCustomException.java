package exception_handling;

import static java.lang.System.in;
import static java.lang.System.out;
//Meaning : you can directly(w/o class name) access the static method
import static utils.ValidationRules.validateVehicleSpeed;

import java.util.Scanner;

public class TestCustomException {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(in)) {
			out.println("Enter speed");
			validateVehicleSpeed(sc.nextInt());
			System.out.println("end of try...");
		} //sc.close()
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("main over...");

	}

}
