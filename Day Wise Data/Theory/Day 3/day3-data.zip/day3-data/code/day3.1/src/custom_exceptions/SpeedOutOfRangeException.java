package custom_exceptions;

@SuppressWarnings("serial")//telling the javac : to suppress warnings regarding serialization
public class SpeedOutOfRangeException extends Exception {
	public SpeedOutOfRangeException(String message) {
		super(message);//invoking super cls ctor to init err mesg
	}
}
