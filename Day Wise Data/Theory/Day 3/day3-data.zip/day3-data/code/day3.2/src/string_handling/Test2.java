package string_handling;
/*
 * If you want to test the equality of 2 strings , ALWAYS use : equals method
 */
public class Test2 {

	public static void main(String[] args) {
		
		// == vs equals
		String s1=new String("testing");
		String s2=new String("testing");
		String s3=s2.toUpperCase();
		System.out.println(s1==s2);//f : reference (address) equality
		System.out.println(s1==s3);//f :  reference (address) equality
		System.out.println(s1.equals(s2));//t : contents equality
		System.out.println(s1.equals(s3));//f
		System.out.println(s1.equalsIgnoreCase(s3));//t

	}

}
