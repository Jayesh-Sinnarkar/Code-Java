package string_handling;

public class Test1 {

	public static void main(String[] args) {
		//immutability of strings
		String s=new String("hello");
		s.concat("hi");
		System.out.println(s);//hello
		 s+="123456";//s=s+"123456";
		 System.out.println(s);//hello123456
		 String s1=s.toUpperCase();//new string obj : with uppercased HELLO123456
		 System.out.println(s);//hello123456
		 System.out.println(s1);//HELLO123456
		 //replace l by t
		 String s2=s.replace('l', 't');
		 System.out.println(s);//orig
		 System.out.println(s2);//replace

	}

}
