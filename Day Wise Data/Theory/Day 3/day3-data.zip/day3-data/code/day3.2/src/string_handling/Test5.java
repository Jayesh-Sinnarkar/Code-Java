package string_handling;

public class Test5 {

	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("hello");
		System.out.println(sb);//sb.toString()
		System.out.println(sb.length()+" capa "+sb.capacity());// 5 21
		StringBuilder sb2=sb.append(false).append('Z').append(123.45).append("fhfdf");
		System.out.println(sb);//appended !
		System.out.println(sb2);//appended
		System.out.println(sb2.length()+" capa "+sb2.capacity());
		System.out.println(sb==sb2);//t

	}

}
