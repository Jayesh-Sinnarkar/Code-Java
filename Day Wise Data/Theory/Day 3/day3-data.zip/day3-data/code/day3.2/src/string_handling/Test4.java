package string_handling;

public class Test4 {

	public static void main(String[] args) {
		String s="testing strings API testing again";
		System.out.println("1st char "+s.charAt(0)+" last char "+s.charAt(s.length()-1));
		System.out.println(s.contains("Ring"));//t
		System.out.println(s.indexOf("testing")+"  "+s.lastIndexOf("testing"));
		String[] names= {"Anish","Amiti","Ritesh","Riya","Mihir","Ankita","Akhil"};
		System.out.println("result "+names[0].compareTo(names[5]));
		

	}

}
