package nested;

public class TryNested1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TryNested.StaticNested s1=new TryNested.StaticNested();

	}

}
