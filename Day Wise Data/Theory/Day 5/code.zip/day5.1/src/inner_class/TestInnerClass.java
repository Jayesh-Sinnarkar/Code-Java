package inner_class;

public class TestInnerClass {

	public static void main(String[] args) {
		// how to invoke inner cls's non static method?
		A.B innerRef=new A(11).new B(13);
		innerRef.innerShow();
		//outer cls instance
		A a1=new A(21);
		A.B innerRef2=a1.new B(22);
		innerRef2.innerShow();

	}

}
