package inner_class;

public class A {
	private int i;
	private static int j;
	static {
		System.out.println("in static init block");
		j = 10;
	}

	public A(int i) {
		super();
		this.i = i;
	}

	// can u add a static method in the outer cls ? YES
	// what all it can access directly : j
	public static void outerShow() {
		System.out.println("in outer's show " + j);
		//how to invoke innerShow() ?
	}

	// can u add a non static method in the outer cls ? YES
	// what all it can access directly :i, j
	public void outerShow2() {
		System.out.println("in outer's instance show " +this.i + " " + j);
		//how to invoke innerShow() ?
	}

	// non static nested class : inner class
	// which are the legal access specifiers for the inner class : private
	// /default/protected/public
	public class B {
		//can inner class contain non static data member ?
		private int k;
		//can inner class contain a static data member ? NO
//		private static int l;
		//Since JDK 1.8 onwards : can declare static constants 
		private static final int l=100;
		//can u add a  static init block in the inner class : NO
//		static {
//			l=100;
//		}
		public B(int k) {
			super();
			this.k = k;
		}
		//can u add a static method in the inner class ? NO
//		static void test()
//		{
//			
//		}
		//can u add a non-static method in the inner class ? YES
		public void innerShow()
		{
			//what all u can access from this method ? i , j , k ,l
			System.out.println("showing members "+A.this.i+" "+j+" "+this.k+" "+l);
		}	
	
	}

}
