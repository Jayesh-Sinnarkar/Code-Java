package pre_generics;

public class Test {

	public static void main(String[] args) {
		// create Holder class instance to hold a double value : 123.45
		Holder holder1 = new Holder(123.45);// double ---> auto boxing --> Double -->up casting --> Object
		System.out.println("loaded class "+holder1.getClass());//pre_generics.Holder
		System.out.println("loaded class for ref "+holder1.getRef().getClass());//java.lang.Double
		double data=(Double)holder1.getRef();//expl : down casting , impl : auto un boxing
		//create another Holder class instance to hold a string : "Hello"
		Holder holder2=new Holder("Hello");//up casting
		String s=(String)holder2.getRef();//explicit down casting
		holder1=holder2;//no javac err
		data=(Double)holder1.getRef();//run time err : class cast exc : string can't be cast double
	}

}
