package generics;

public class Test {

	public static void main(String[] args) {
		// create Holder class instance to hold a double value : 123.45
		Holder<Double> holder1 = new Holder<>(123.45);// impl conv : auto boxing(double --Double)
		double data = holder1.getRef();// impl conv : Double --> double
		// create another Holder class instance to hold a string : "Hello"
		Holder<String> holder2 = new Holder<>("Hello");// impl conv : NONE!
		String s = holder2.getRef();
	//	holder1 = holder2;// javac detects type mis match errs ! --no possibility of class cast exc !!!!
	}

}
