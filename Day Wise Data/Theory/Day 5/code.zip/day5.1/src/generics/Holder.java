package generics;
//Create a Holder class , that can hold ANY data type (primitive/ref type)
public class Holder<T> {
//state : instance var 
	private T ref;

	public Holder(T ref) {
		super();
		this.ref = ref;
	}

	public T getRef() {
		return ref;
	}
	
}
