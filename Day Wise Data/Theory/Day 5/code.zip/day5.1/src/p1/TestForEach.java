package p1;

import java.util.Scanner;

public class TestForEach {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("how many ints");
			int[] data=new int[sc.nextInt()];
			//display array data using for-each
			System.out.println("printing def array");
			for(int i : data)//i=data[0]......i=data[data.length-1]
				System.out.print(i+"  ");
			System.out.println();
			//init array : for-each
			for(int i : data)
			{
				System.out.println("Enter data");
				i=sc.nextInt();
			}
			System.out.println("printing inited array");
			for(int i : data)//i=data[0]......i=data[data.length-1]
				System.out.print(i+"  ");
	
		}

	}

}
