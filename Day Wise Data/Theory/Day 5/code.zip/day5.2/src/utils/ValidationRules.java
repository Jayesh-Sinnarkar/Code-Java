package utils;

import java.time.LocalDate;

import com.app.core.Color;

import custom_exceptions.InvalidInputException;

public class ValidationRules {
//add a static method to validate manu. date : must be in current  year
	// (eg : 1st Jan 2023 onwards)
	public static LocalDate validateManufactureDate(String date) throws InvalidInputException{
		// parse
		LocalDate d1 = LocalDate.parse(date);// yyyy-MM-dd
		// => parsing success!
		LocalDate yearBegin = LocalDate.of(LocalDate.now().getYear(), 1, 1);
		if (d1.isAfter(yearBegin))
			return d1;
		// => invalid date
		throw new InvalidInputException("Manufacture date must be in curnt year!!!!!");

	}
	//add a static method to validate color
	public static Color validateVehicleColor(String clr)
	{
		//in case of success --rets Colore or JVM will throw the exc : IllegalArgExc
		return Color.valueOf(clr.toUpperCase());
	}
}
