package tester;

import java.time.LocalDate;
import java.util.Scanner;

import com.app.core.Color;
import com.app.core.Vehicle;
import static utils.ValidationRules.*;

import custom_exceptions.InvalidInputException;

public class ShowroomManagement {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter showroom capacity");
			Vehicle[] showroom = new Vehicle[sc.nextInt()];// 1 array obj : array of vehicle type of refs.
			boolean exit = false;
			int counter = 0;
			while (!exit) {
				System.out.println("1. Add a Vehicle 2. Display all 0. Exit");
				System.out.println("Choose an option");
				try {
					switch (sc.nextInt()) {
					case 1:
						if (counter < showroom.length) {
							System.out.println(
									"Enter vehicle details : chasisNo,  vehicleColor,  basePrice,  manufactureDate,  company");
							String chNo = sc.next();
							// invoke validation rule : color
							Color clr = validateVehicleColor(sc.next());
							double basePrice = sc.nextDouble() + clr.getAdditionalCost();
							LocalDate date = validateManufactureDate(sc.next());
							String company = sc.next();
							// => validation success --so create vehicle object n add it's ref in the array
							showroom[counter++] = new Vehicle(chNo, clr, basePrice, date, company);
							System.out.println("vehicle added to the showroom!");
						} else
							throw new InvalidInputException("Showroom full!!!!!");
						break;
					case 2:
						System.out.println("Showroom details ");
						for (Vehicle v : showroom)
							if (v != null)
								System.out.println(v);// v.toString()
						break;
					case 0:
						exit = true;
						break;

					}
				} catch (Exception e) {
					e.printStackTrace();
					// read off all pending tokens from the scanner
					sc.nextLine();
				}
			}

		}

	}

}
