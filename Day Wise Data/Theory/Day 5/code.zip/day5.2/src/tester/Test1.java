package tester;

import java.time.LocalDate;

import com.app.core.Color;
import com.app.core.Vehicle;

public class Test1 {

	public static void main(String[] args) {
		// String chasisNo, Color vehicleColor, double basePrice, LocalDate
		// manufactureDate, String company
		Vehicle v1 = new Vehicle("mh-12345", Color.BLACK, 567890, 
				LocalDate.parse("2020-01-12"), "Honda");
		Vehicle v2 = new Vehicle("mh-12345", Color.BLACK, 567890, 
				LocalDate.parse("2020-01-12"), "Honda");
		System.out.println(v1==v2);//f
		System.out.println(v1.equals(v2));//t

	}

}
