package generics;

import java.util.Arrays;
import java.util.List;

public class TestGenericMethod {

	public static void main(String[] args) {
		//examle of the generic method
		// Arrays.asList
		//public static <T> List<T> asList(T... args)
		//How will you use it for getting a fixed size List<Integer> ? : 10,20,30,1,3,4,5
		List<Integer> intList=Arrays.asList(new Integer[] {10,20,30,1,3,4,5});
		System.out.println(intList);
		List<Integer> intList2=Arrays.asList(10,20,30,1,3,4,5,8,9,12345);//auto boxing
		System.out.println(intList2);
		List<Double> doubleList=Arrays.asList(10.0,20.7,30.7);
		System.out.println(doubleList);

	}

}
