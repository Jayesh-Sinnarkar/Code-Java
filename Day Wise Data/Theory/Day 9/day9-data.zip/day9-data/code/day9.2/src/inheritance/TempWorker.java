package inheritance;

public class TempWorker extends Worker{

}
