package generics;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import inheritance.Emp;
import inheritance.SalesMgr;
import inheritance.TempWorker;

public class Test1 {

	public static void main(String[] args) {
		Emp e = new SalesMgr();// up casting
		e = new TempWorker();// up casting
		List<Emp> emps;
		ArrayList<SalesMgr> sMgrs = new ArrayList<>();
		sMgrs.add(new SalesMgr());
		sMgrs.add(new SalesMgr());
//		emps=sMgrs;
		List<Object> objs;
		// objs=sMgrs; Even though SalesMgr IS-A Object , LIst<SalesMgr> IS NOT
		// inheriting from List<Object>
		List<?> anyList;
		anyList=sMgrs;
		anyList=new Vector<TempWorker>();

	}

}
