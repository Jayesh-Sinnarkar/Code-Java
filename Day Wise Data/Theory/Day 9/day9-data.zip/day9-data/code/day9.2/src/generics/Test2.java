package generics;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		
		List<String> strings=Arrays.asList("one","two","three","four","five");
		System.out.println(strings);
		//shuffle list of Strings
		//Collections : public static void shuffle(List<?> list)
		Collections.shuffle(strings);
		System.out.println(strings);
		//can u use above method to shuffle Vector<Integer> ? YES
		List<Integer> ints=Arrays.asList(1,2,3,54,6,678);
		Collections.shuffle(ints);
		System.out.println(ints);	

	}

}
