package inheritance;

public class SalesMgr extends Mgr{

}
