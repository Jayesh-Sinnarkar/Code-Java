package inheritance;

public class Emp {

}
