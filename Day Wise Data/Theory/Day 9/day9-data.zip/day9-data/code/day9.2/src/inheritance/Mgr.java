package inheritance;

public class Mgr extends Emp{

}
