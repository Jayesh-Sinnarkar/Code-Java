package inheritance;

public class Worker extends Emp{

}
