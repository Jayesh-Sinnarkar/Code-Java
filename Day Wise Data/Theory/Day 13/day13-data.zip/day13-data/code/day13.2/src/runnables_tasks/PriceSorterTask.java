package runnables_tasks;

import java.util.Map;
import java.util.stream.Stream;

import com.shop.core.Product;

import utils.IOUtils;

public class PriceSorterTask implements Runnable {
	// state (non static data members)
	private String fileName;
	private Map<Integer, Product> products;

	// add parameterized ctor : to init state
	public PriceSorterTask(String fileName, Map<Integer, Product> products) {
		super();
		this.fileName = fileName;
		this.products = products;
		System.out.println("ctor invoked by " + Thread.currentThread().getName());
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			Stream<Product> sortedStream = products.values() // Collection<Product> : un sorted
					.stream() // Stream<Product> : un sorted
					.sorted((p1, p2) -> ((Double) p1.getPrice()).compareTo(p2.getPrice())); // Stream<Product>
																							// : sorted as per price
			// store these elems in text file
			IOUtils.storeProductDetails(sortedStream, fileName);
			System.out.println("saved sorted products .....");

		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + " got err " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");

	}

}
