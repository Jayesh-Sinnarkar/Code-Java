package tester;

import java.util.Map;
import java.util.Scanner;

import com.shop.core.Product;

import runnables_tasks.DateSorterTask;
import runnables_tasks.PriceSorterTask;

import static utils.ShopUtils.*;

public class TestCollectionIOThreads {

	public static void main(String[] args) {
		// sc
		try (Scanner sc = new Scanner(System.in)) {
			// get map
			Map<Integer, Product> productMap = populateProductMap(populateProductList());
			System.out.println("Enter file name to store sorted products as per date");
			String fileName1 = sc.next();
			System.out.println("Enter file name to store sorted products as per price");
			String fileName2 = sc.next();
			// Thread(Runnable instance,String nm)
			Thread t1 = new Thread(new DateSorterTask(fileName1, productMap), "date_sorter");
			Thread t2=new Thread(new PriceSorterTask(fileName2, productMap), "price_sorter");
			//start thrds
			t1.start();
			t2.start();//runnable : 3
			System.out.println("main waiting for child thrds to complete exec");
			t1.join();
			t2.join();			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("main over....");

	}

}
