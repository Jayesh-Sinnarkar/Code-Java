package utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.stream.Stream;

import com.shop.core.Product;

public interface IOUtils {
//add a static method to store sorted product details in a text file , using buffering
	static void storeProductDetails(Stream<Product> sortedProducts, String fileName) throws IOException {
//Java App  ----> PW ---> FW ---> Text File
		try (PrintWriter pw = new PrintWriter(new FileWriter(fileName))) {
			sortedProducts.forEach(pw::println);// p -> pw.println(p)
		} // pw.close --> buf flushed to fw --> file , file closed!
	}
}
