package thrds3;

public class Tester {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());// Thread [main,5,main]
		// test concurrency
		// create a runnable task
		RunnableTask task = new RunnableTask();
		// Thread(Runnable task,String name)
		Thread t1 = new Thread(task, "one");
		Thread t2 = new Thread(task, "two");
		Thread t3 = new Thread(task, "three");
		Thread t4 = new Thread(task, "four");//runnable : main
		t1.start();
		t2.start();
		t3.start();
		t4.start();//1+4 : runnable
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(200);
		}
		System.out.println("main waiting child thrds to complete exec");
		System.out.println(t1.isAlive()+" "+t4.isAlive());//t t
		t1.join();//main waiting t1 
		t2.join();//main waiting t2
		t3.join();//main waiting t3 
		t4.join();//main waiting t4 
		System.out.println(t1.isAlive()+" "+t4.isAlive());//f f
		System.out.println("main over....");

	}

}
