package thrds4;

public class Tester {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());// Thread [main,5,main]
		// test concurrency
		// create a runnable task
		RunnableTask task = new RunnableTask();
		// Thread(Runnable task,String name)
		Thread t1 = new Thread(task, "one");
		Thread t2 = new Thread(task, "two");
		Thread t3 = new Thread(task, "three");
		Thread t4 = new Thread(task, "four");//runnable : main
		t1.start();
		t2.start();
		t3.start();
		t4.start();//1+4 : runnable
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(200);
		}
		System.out.println("main waiting child thrds(t1,t3,t4) to complete exec");
		System.out.println(t1.isAlive()+" "+t4.isAlive());//t t
		t1.join();//main waiting t1 
		t3.join();//main waiting t3 
		t4.join();//main waiting t4 
		t2.join(3000);//main waiting t2
		System.out.println("main continuing after join's tmout.....");
		System.out.println("main sending interrupt to t2 : blocked on i/p");
		t2.interrupt();
		System.out.println(t1.isAlive()+" "+t2.isAlive());//f t
		System.out.println("main over....");

	}

}
