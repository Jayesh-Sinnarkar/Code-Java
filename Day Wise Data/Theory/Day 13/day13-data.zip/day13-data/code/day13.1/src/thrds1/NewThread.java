package thrds1;

//extends Thread scenario
public class NewThread extends Thread {
	//add a paramterized ctor to create named thrd
	public NewThread(String name) {
		super(name);
	}

	// Mandatory to create meaningful thrd
	@Override
	public void run() {
		System.out.println(getName() + " strted");
		try {
			for (int i = 0; i < 10; i++) {
				System.out.println(getName() + " exec # " + i);
				Thread.sleep(500);
			}
		} catch (Exception e) {
			System.out.println(getName() + " got exc " + e);
		}
		System.out.println(getName() + " over");
	}
}
