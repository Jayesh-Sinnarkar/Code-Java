package thrds1;

public class Tester {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());// Thread [main,5,main]
		// test concurrency
		NewThread t1 = new NewThread("one");// runnable : 1 : main
		NewThread t2 = new NewThread("two");// runnable : 1 : main
		NewThread t3 = new NewThread("three");// runnable : 1 : main
		NewThread t4 = new NewThread("four");// runnable : 1 : main
		t1.start();
		t2.start();
		t3.start();
		t4.start();// runnable : 1 + 4
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(1000);
		}
		System.out.println("main over....");
		

	}

}
