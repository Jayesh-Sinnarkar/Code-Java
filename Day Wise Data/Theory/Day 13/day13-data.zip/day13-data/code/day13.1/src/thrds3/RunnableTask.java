package thrds3;
import static java.lang.Thread.*;

//imple. Runnable scenario
public class RunnableTask implements Runnable {
	

	// Mandatory to create meaningful thrd. o.w : javac err
	@Override
	public void run() {
		System.out.println(currentThread().getName() + " strted");
		try {
			for (int i = 0; i < 10; i++) {
				System.out.println(currentThread().getName() + " exec # " + i);
				sleep(500);
			}
		} catch (Exception e) {
			System.out.println(currentThread().getName() + " got exc " + e);
		}
		System.out.println(currentThread().getName() + " over");
	}
}
