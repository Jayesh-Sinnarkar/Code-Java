package test;

public class Test {

	public static String s7="hi";//new String("hi");

}
