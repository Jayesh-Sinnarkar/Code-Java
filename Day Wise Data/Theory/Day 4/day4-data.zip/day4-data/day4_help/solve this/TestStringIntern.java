package test;

import static test.Test.s7;

public class TestStringIntern {

	public static void main(String[] args) {

		String s1 = "hi";
		String s2 = new String(s1);
		String s3 = s2.intern(); 
		String s4 = "hi";
		String s5 = "h".concat("i"); 
		String s6 = "h" + "i";		
		
		System.out.println(s1 == s2);
		System.out.println(s1 == s3);
		System.out.println(s2 == s3);
		System.out.println(s1 == s4);
		System.out.println(s1 == s5);
		System.out.println(s1 == s6);
		System.out.println(s1 == s7);
		
		String s8=new String("Hello");
		String s9=s8.intern();
		System.out.println(s8==s9);
		
	
	}

}
