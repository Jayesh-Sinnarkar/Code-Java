package var_args;

public class Horse extends Animal {
	public Horse(String name) {
		super(name);
	}
}
