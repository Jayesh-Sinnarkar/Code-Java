package enums;

public enum Color{
//set of related constants
	RED,BLACK,SILVER,WHITE,BLUE;
	@Override
	public String toString()
	{
		return name().toLowerCase();
	}
}
