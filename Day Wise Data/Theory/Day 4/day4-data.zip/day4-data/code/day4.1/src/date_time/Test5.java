package date_time;

import java.time.LocalDate;
import java.util.Scanner;
//import all static members of LocalDate
import static java.time.LocalDate.*;
import static java.time.Period.between;

public class Test5 {

	public static void main(String[] args) {
		// compute user's age
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter  date 1: yr , mon ,day");
			LocalDate d1=of(sc.nextInt(),sc.nextInt(),sc.nextInt());
			System.out.println("Enter  date 2: yr , mon ,day");
			LocalDate d2=of(sc.nextInt(),sc.nextInt(),sc.nextInt());
			System.out.println(d1.isBefore(d2));
			System.out.println(d1.isAfter(d2));
			System.out.println(d1.isEqual(d2));
			System.out.println(d1.compareTo(d2));
			System.out.println("Enter no of days to elapse after 2nd date");
			//display elapsed date
			LocalDate futureDate=d2.plusDays(sc.nextLong());
			System.out.println("Future Date "+futureDate);
			System.out.println(d2==futureDate);//false => immutability
		
			
		}

	}

}
