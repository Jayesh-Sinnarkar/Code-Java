package date_time;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Test3 {

	public static void main(String[] args) {
		LocalDate curntDate=LocalDate.now();
		System.out.println("curnt date "+curntDate);
		LocalTime curntTime=LocalTime.now();
		System.out.println("curnt time "+curntTime);
		LocalDateTime timeStamp=LocalDateTime.now();
		System.out.println("curnt TS "+timeStamp);

	}

}
