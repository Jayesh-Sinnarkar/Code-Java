package var_args;

public class Test1 {

	public static void main(String... args) {
		printAnimalNames();
		System.out.println("----------------------");
		printAnimalNames(new Animal[] { new Dog("Casper"), 
				new Cat("Mojo"), new Horse("Speedy") });
		System.out.println("-----------------------");
		Animal a1=new Dog("Pluto");
		Animal a2=new Cat("Catty");
		printAnimalNames(a1,a2);

	}

	private static void printAnimalNames(Animal... animals) {
		for (Animal a : animals)
			System.out.println(a.getName());
	}

}
