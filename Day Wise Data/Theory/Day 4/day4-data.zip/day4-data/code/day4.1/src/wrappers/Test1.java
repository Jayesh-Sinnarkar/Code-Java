package wrappers;

public class Test1 {

	public static void main(String[] args) {
		// Integer i1=new Integer(1234);
		Integer i1 = Integer.valueOf(1234);// boxing =>explicit primitive int --> Integer
		int data = i1.intValue();// un boxing => explicit conversion wrapper Integer --> int
		Integer i3 = 12345;// auto boxing , implicit conversion : primitive int --> Integer
		Double d1 = 123.45;// auto boxing
		data = i3;// auto un boxing
		double val = d1;// auto un boxing
		Character c = 'a';
		Boolean status = true;
		String s = "asdfgh";
		// s++; Can not use arithmetic ops on ref types.
		i1++;// auto un boxing(int tmp=i1.intValue(), tmp++ , i1=Integer.valueOf(tmp)
				// --inc--auto boxing
		System.out.println(i1);// i1.toString()
		double d2 = 12345;// int --> double : widening conversion
		d2 = 1234.56f;// float --> double : widening conversion
		// d1=1234.56f;//float ---> auto boxing --> Float CAN NOT be up casted to Double
		d1 = (double) 1234.56f;// expl : float --> double , impl : auto boxing
		// d1=34567;
		Number n = 123.456F;// auto boxing --> up casting
		System.out.println("loaded  class " + n.getClass());
		n = 122;
		System.out.println("loaded  class " + n.getClass());
		Object o = true;// auto boxing boolean --> Boolean --> up casted to Object
		System.out.println("cls loaded " + o.getClass());// Boolean
		o = 123.456;
		o = 12456;
		o = 'f';
		o = "hello";// up casting
		// Is Java pure OOP : NO
		// Can Object type of a reference DIRECTLY (w/o type casting) refer to ANY (any
		// prim / any ref) data type in Java? : YES (autoboxing + up casting / up
		// casting)

	}

}
