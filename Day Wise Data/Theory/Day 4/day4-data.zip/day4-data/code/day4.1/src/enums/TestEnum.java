package enums;

import java.util.Scanner;

/*
 * Q : display available colors to the user
 * Prompt user for the color (string) --> enum
 */
public class TestEnum {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Available colors : ");
			for(Color c : Color.values())//Color[]
				System.out.println(c);//c.toString() : uses inhertied from Enum class
			System.out.println("Choose color");
			Color chosenColor=Color.valueOf(sc.next().toUpperCase());
			System.out.println("You chose "+chosenColor);
		}//sc.close()

	}

}
