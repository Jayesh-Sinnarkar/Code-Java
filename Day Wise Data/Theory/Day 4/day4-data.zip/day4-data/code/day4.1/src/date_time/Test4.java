package date_time;

import java.time.LocalDate;
import java.util.Scanner;
//import all static members of LocalDate
import static java.time.LocalDate.*;
import static java.time.Period.between;

public class Test4 {

	public static void main(String[] args) {
		// compute user's age
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter DoB : yyyy-MM-dd");
			LocalDate dob=parse(sc.next());
			int ageInYears=between(dob, now()).getYears();
			System.out.println("age "+ageInYears);
		}

	}

}
