package date_time;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			// 1. SDF instance
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			// accept date from user n print it in formatted manner
			System.out.println("Enter DoB : yyyy-MM-dd");
			Date dob = sdf.parse(sc.next());// parsing
			System.out.println("dob " + dob);//toString of Date
			System.out.println("formatted  dob " + sdf.format(dob));//yyyy-MM-dd
			System.out.println("end of try....");
		} // JVM : sc.close()
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("main over....");

	}

}
