package var_args;

public class Animal {
	private String name;

	public Animal(String name) {
				this.name = name;
	}
	//getter for name

	public String getName() {
		return name;
	}
	

	
}
