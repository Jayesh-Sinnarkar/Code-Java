package lists;

import java.util.ArrayList;
import java.util.Collections;

/*
 * Revise AL API
 */
public class TestIntegerList {

	public static void main(String[] args) {
		// create empty AL to hold integer type refs
		ArrayList<Integer> intList=new ArrayList<>();//empty List
		System.out.println("Empty list contents : ");
		for (int i : intList) // conv : auto un boxing
			System.out.print(i+" ");
		System.out.println("AL via toString "+intList);//[]
	
		//create int[] 
		int[] data= {10,1,23,45,56,100,-10,10,1,2,5};
		//populate the AL with the data : add
		for(int i : data) //conversion : NO ! 
			intList.add(i); //conv : auto boxing (intList.add(Integer.valueOf(i))
		//display the list elems : for each
		System.out.println("List contents via for-each");
		for (int i : intList) // conv : auto un boxing
			System.out.print(i+" ");
		//search for the element
		System.out.println(intList.contains(56)?"Exists":"Doesn't Exist");//auto conv : auto boxnin
		//display index of first occur n last of 10
		System.out.println(intList.indexOf(10)+" last index "+intList.lastIndexOf(10));//auto conv : auto boxnin
		//retrieve elem by it's index
		System.out.println(intList.get(intList.size()-1));//5
		//remove
		System.out.println("Removed element "+intList.remove(3));
		System.out.println("list after remove"+intList );
		//replace 
		for(int i=0;i<intList.size();i++)
			if(intList.get(i)> 50)
				intList.set(i, intList.get(i)*2);
		System.out.println("list after replace"+intList );
		
		Collections.sort(intList);
		System.out.println("Sorted list "+intList);
	}

}
