package java8_features3;

public class Test1 {

	public static void main(String[] args) {
		Formula[] formulae= {new Formula1(),new Formula2()};//3 objs
		for(Formula f : formulae)//f=formulae[0],f=formulae[1]
		{
			System.out.println(f.calculate(10, 20));
			System.out.println(f.sqrt(13,12));
		}

	}

}
