package java8_features2;

public interface B {
	default double calc(double a, double b) {
		return a+b;
	}
}
