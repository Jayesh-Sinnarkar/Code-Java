package java8_features;

public class Formula1 implements Formula{

	@Override
	public double calculate(double d1, double d2) {
		System.out.println("imple abstract method in imple class "+PI);
		return d1+d2;
	}

}
