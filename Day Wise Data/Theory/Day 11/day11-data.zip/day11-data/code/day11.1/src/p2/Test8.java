package p2;
import static utils.ShopUtils.*;

import java.time.LocalDate;
import java.util.Map;

import com.shop.core.Product;
public class Test8 {

	public static void main(String[] args) {
		// get populated product map from shop utils n display the same
		Map<Integer, Product> productMap = populateProductMap(populateProductList());
		//display all prodcust ids n product details :
		//Map : public void forEach(BiConsumer<? super K,? super V> action)
		//SAM public void accept(K k, V v)
		System.out.println("map details");
		productMap.forEach((k,v) -> System.out.println("Id "+k+" : "+v));
		LocalDate date=LocalDate.of(2022, 5, 1);
		//remove all products manu. date before date
		productMap.values().removeIf(p -> p.getManufactureDate().isBefore(date));
		System.out.println("map after remove");
		productMap.forEach((k,v) -> System.out.println("Id "+k+" : "+v));
		//add the entry in the map n then use this code : H.W
		productMap.values().forEach(p -> System.out.println(p));		
	}

}
