package p1;

import static p1.ComputationUtils.invokeCompute;

public class Test1 {

	public static void main(String[] args) {
		// 10 20 , add
//		System.out.println(invokeCompute(10, 20, new Computable() {
//
//			@Override
//			public double compute(double a, double b) {
//				// TODO Auto-generated method stub
//				return a + b;
//			}
//		}));
		// re write above func by using a lambda expr
		System.out.println(invokeCompute(10, 20, (double d1, double d2) -> {
			return d1 + d2;
		}));

		// 10 20 , multiply
//		System.out.println(invokeCompute(10, 20, new Computable() {
//
//			@Override
//			public double compute(double a, double b) {
//				// TODO Auto-generated method stub
//				return a * b;
//			}
//		}));
		// Java SE 8 onwards --- You can pass behavior(func) to another method : Func
		// prog. feature
		// higher order function/method : Any func/method :where u can pass the behavior
		// OR ret the behavior
		System.out.println(invokeCompute(12, 13, (a, b) -> a * b));
		System.out.println(invokeCompute(12, 13, (a, b) -> a / b));
		// function literal = assigning func def(lamda expr) to a variable
		//int a=100;//int literal
		String s="dgadfg";//string literal
		Computable ref=(a, b) -> a - b;//func literal
		//subtract 2 nums n display the res
		System.out.println(invokeCompute(12, 10, ref));
		

	}

}
