package p1;

public interface ComputationUtils {
//add a static method to invoke compute(..) 
	//higer order method
	static double invokeCompute(double a,double b,Computable operation) {
		return operation.compute(a, b);
	}
}
