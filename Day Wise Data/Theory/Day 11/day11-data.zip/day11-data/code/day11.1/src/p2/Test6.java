package p2;

import static utils.ShopUtils.populateProductList;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.shop.core.Product;

public class Test6 {

	public static void main(String[] args) {
		// get populated product list
		List<Product> productList = populateProductList();
		System.out.println("original list");
		productList.forEach(product -> System.out.println(product));
		// sort the products as per manufacturing date
		// display the sorted list
//		Collections.sort(productList, new Comparator<Product>() {
//
//			@Override
//			public int compare(Product o1, Product o2) {
//				// TODO Auto-generated method stub
//				return o1.getManufactureDate().compareTo(o2.getManufactureDate());
//			}
//			
//		});
//		Collections.sort(productList,
//(p1, p2) -> p1.getManufactureDate().compareTo(p2.getManufactureDate()));
		// func literal
		Comparator<Product> prodComparator = (p1, p2) -> p1.getManufactureDate().compareTo(p2.getManufactureDate());
		Collections.sort(productList, prodComparator);
		System.out.println("sorted  list as per date");
		productList.forEach(product -> System.out.println(product));
	}

}
