package java8_features2;

public class C implements A,B{
//in case of ambiguity , javac FORCES upon  imple class : to override def method
	@Override
	public double calc(double a1,double a2)
	{
		//how to access inherited def func ? : i/fName.super.method
		System.out.println(A.super.calc(a1, a2));
		System.out.println(B.super.calc(a1, a2));
		return a1*a2;
	}
}
