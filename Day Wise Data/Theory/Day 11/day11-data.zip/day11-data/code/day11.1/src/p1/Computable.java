package p1;

@FunctionalInterface
public interface Computable {
//Create a func i/f : to wrap : SAM that represents ANY math op. on 2 doubles
	double compute(double a, double b);

//	default void show() {
//		System.out.println("in show");
//	}
//
//	static boolean isEven(int i) {
//		return i % 2 == 0;
//	}

}
