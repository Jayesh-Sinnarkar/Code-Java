package java8_features3;

public class Formula1 implements Formula{

	@Override
	public double calculate(double d1, double d2) {
		System.out.println("imple abstract method in imple class "+PI);
		return d1+d2;
	}
	//can u override a static method ? NO , BUT it can be re-declared!
//	@Override
	static void show()
	{
		System.out.println("in class's  static method");
	}

}
