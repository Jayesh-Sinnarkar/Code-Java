package com.acts.tester;

import com.acts.Box;

import java.util.ArrayList;
import java.util.Arrays;
//A separate class for UI
import java.util.Scanner;

public class TestBox {

	public static void main(String[] args) {
		int[] data = { 1, 3, 5, 6, 7, 8 };
		// what will happen?
		for (int i : data)
			i *= 2;
		System.out.println(Arrays.toString(data));// orig array
		// draw mem pic
		Box[] boxes = { new Box(1, 2, 3), new Box(3, 4, 5), new Box(4, 5, 6) };
		System.out.println("Boxes before : ");
		for (Box b : boxes)
			System.out.println(b.getBoxDims());
		// does for-each work on the actual array or it's copy ? : works on a copy
		// can u use for each to double box dims ? YES (since we are NOT modifying array
		// elems BUT the state of the object referred by it)
		for (Box b : boxes) // b=boxes[0] , b=boxes[1]
			b.setWidth(b.getWidth() * 2);
		System.out.println("Boxes after : ");
		for (Box b : boxes)
			System.out.println(b.getBoxDims());//doubled width 
		//draw mem pic
		ArrayList<Box> list=new ArrayList<>();
		for (Box b : boxes)
			list.add(b);
		list.add(new Box(10,20, 30));
	}

}
