package tester;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.acts.Box;

public class TestComparator {

	public static void main(String[] args) {

		Box[] boxes = { new Box(11, 2, 3), new Box(3, 4, 5), new Box(40, 5, 6) };
		ArrayList<Box> list = new ArrayList<>();
		for (Box b : boxes)
			list.add(b);
		list.add(new Box(12, 20, 30));
		for (Box b : list)
			System.out.println(b.getBoxDims());
		// sort these boxes as per asc order of width (w/o touching Box class)
//		Collections.sort(list, new Comparator<Box>() {
//
//			@Override
//			public int compare(Box o1, Box o2) {
//				// sorting : width
////				if (o1.getWidth() < o2.getWidth())
////					return 1;
////				if (o1.getWidth() == o2.getWidth())
////					return 0;
////				return -1;
//				return ((Double)o1.getWidth()).compareTo(o2.getWidth());//asc 
//
//			}
//
//		});
		Collections.sort(list, (o1, o2) -> ((Double) o1.getWidth()).compareTo(o2.getWidth()));
		System.out.println("sorted boxes as per width");
		// print the list : box dims
		list.forEach(b -> System.out.println(b.getBoxDims()));

	}

}
