package sets;

import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		List<String> strings = Arrays.asList("one", "two", "three", "four", "five", "six", "two", "four");
		// Can you populate a LinkedHashSet from above List ? Yes !
		// LinkedHashSet(Collection<? extends E> coll))
		TreeSet<String> hs = new TreeSet<>(strings);//JVM invokes : String's compareTo
		// display : toString
		System.out.println("TS via toString " + hs);
		}

}
