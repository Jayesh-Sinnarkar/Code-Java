package sets;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

public class TestLinkedHashSet {

	public static void main(String[] args) {
		List<String> strings = Arrays.asList("one", "two", "three", "four", "five", "six", "two", "four");
		// Can you populate a LinkedHashSet from above List ? Yes !
		// LinkedHashSet(Collection<? extends E> coll))
		LinkedHashSet<String> hs = new LinkedHashSet<>(strings);
		// display : toString
		System.out.println("LHS via toString " + hs);
		// display HS using Iterator
		System.out.println("LHS via Iterator : ");
		Iterator<String> itr = hs.iterator();
		while (itr.hasNext())
			System.out.println(itr.next());// after last elem
		System.out.println("Added " + hs.add("ten"));// true
		System.out.println("Added " + hs.add("five"));// false
		// un comment to produce concurrent modification exc
//		while (itr.hasNext())
//			System.out.println(itr.next());
		System.out.println("LHS contains one  " + hs.contains("one"));// t
		System.out.println("Removed " + hs.remove("one"));// true
		System.out.println("LHS after remove " + hs);
		System.out.println("LHS contains one  " + hs.contains("one"));// f
		// attach for-each : lab work!
	}

}
