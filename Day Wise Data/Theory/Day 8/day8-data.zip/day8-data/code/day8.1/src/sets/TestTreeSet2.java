package sets;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class TestTreeSet2 {

	public static void main(String[] args) {
		List<String> strings = Arrays.asList("one", "two", "three", "four", "five", "six", "two", "four");
		// Can you populate a LinkedHashSet from above List ? Yes !
		// LinkedHashSet(Collection<? extends E> coll))
		TreeSet<String> hs = new TreeSet<>(new Comparator<String>() {
			@Override
			public int compare(String s1,String s2)
			{
				System.out.println("in compare");
				return s2.compareTo(s1);
			}
		});
		// display the set as per reverse lexicographical ordering
		System.out.println("TS via toString " + hs);//[]
		hs.addAll(strings);//JVM : ano inner's compare
		System.out.println("TS via toString again " + hs);
	}

}
