package sets;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class TestHashSet {

	public static void main(String[] args) {
		List<String> strings = Arrays.asList("one", "two", "three", "four", "five", "six", "two", "four");
		// Can you populate a HashSet from above List ? Yes !
		// HashSet(Collection<? extends E> coll))
		HashSet<String> hs = new HashSet<>(strings);
		// display : toString
		System.out.println("HS via toString " + hs);
		// display HS using Iterator
		System.out.println("HS via Iterator : ");
		Iterator<String> itr = hs.iterator();
		while (itr.hasNext())
			System.out.println(itr.next());// after last elem
		System.out.println("Added " + hs.add("ten"));// true
		System.out.println("Added " + hs.add("five"));// false
		// un comment to produce concurrent modification exc
//		while (itr.hasNext())
//			System.out.println(itr.next());
		System.out.println("HS contains one  " + hs.contains("one"));// t
		System.out.println("Removed " + hs.remove("one"));// true
		System.out.println("HS after remove " + hs);
		System.out.println("HS contains one  " + hs.contains("one"));// f
		// attach for-each : lab work!
	}

}
