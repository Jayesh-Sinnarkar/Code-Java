package sets;

import java.util.HashSet;

import com.app.core.Employee;

public class TestEmpSet3 {

	public static void main(String[] args) {
		Employee e1=new Employee("BBBB", "Riya",12345);
		Employee e2=new Employee("AaBB", "Rita",12345);
		Employee e3=new Employee("AaAa", "Raj",24345);
		Employee e4=new Employee("BBAa", "Ritesh",19345);
//		Employee e5=new Employee("rnd-007", "Amar",12945);
//		Employee e6=new Employee("rnd-003", "Rama",22445);
//		//create empty HS to store emp details
		HashSet<Employee> emps=new HashSet<>();//size=0, init capa=16, L.F : 0.75
		System.out.println("Added "+emps.add(e1));//t , hC : 1
		System.out.println("Added "+emps.add(e2));//t , hc :1 , eq : 1
		System.out.println("Added "+emps.add(e3));//t , hc :1 ,eq : 2
		System.out.println("Added "+emps.add(e4));//t, hc : 1 , eq :3
//		System.out.println("Added "+emps.add(e5));//t
//		System.out.println("Added "+emps.add(e6));//t , hc :1
//		System.out.println("size "+emps.size());//5
//		for(Employee e : emps)
//			System.out.println(e);//no dups!
		//BBBB AaBB AaAa BBAa
//		System.out.println("BBBB".equals("AaBB"));//f
//		System.out.println("BBBB".hashCode()+" "+"AaBB".hashCode());//same

	
	}

}
