package maps;

import static utils.ShowroomUtils.populateShowroom;

import java.util.HashMap;
import java.util.List;

import com.app.core.Vehicle;

public class TestHashMap {

	public static void main(String[] args) {
		try {
			List<Vehicle> showroom = populateShowroom();
			//How will you add these vehicles in HashMap ?
			//1. Key : String(ch no) , Value : Vehicle
			HashMap<String, Vehicle> vehicleMap=new HashMap<>();//size=0,init capa =16, L.F : 0.75
			//populate HM with vehicle's data
			for(Vehicle v : showroom)
				System.out.println("Added "+vehicleMap.putIfAbsent(v.getChasisNo(), v));
			System.out.println("Map "+vehicleMap);
			System.out.println("size "+vehicleMap.size());
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
