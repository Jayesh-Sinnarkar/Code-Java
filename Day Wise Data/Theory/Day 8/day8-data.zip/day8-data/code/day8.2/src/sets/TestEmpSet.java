package sets;

import java.util.HashSet;

import com.app.core.Employee;

public class TestEmpSet {

	public static void main(String[] args) {
		Employee e1=new Employee("rnd-001", "Riya",12345);
		Employee e2=new Employee("rnd-001", "Riya",12345);
		Employee e3=new Employee("rnd-009", "Raj",22345);
		//create empty HS to store emp details
		HashSet<Employee> emps=new HashSet<>();
		System.out.println("Added "+emps.add(e1));//t
		System.out.println("Added "+emps.add(e2));//t
		System.out.println("Added "+emps.add(e3));//t
		System.out.println("size "+emps.size());//3
		for(Employee e : emps)
			System.out.println(e);//no dups !
		System.out.println(e1.equals(e2));//t
		System.out.println(e1.hashCode()+" "+e2.hashCode());//same or different : different

	}

}
