package com.app.core;

public class Employee {
	private String id;
	private String name;
	private double salary;

	public Employee(String id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

	// override equals : to replace ref equality by contents (PK : emp id) equality
	@Override
	public boolean equals(Object o) {
		System.out.println("in emp equals");
		if (o instanceof Employee)
			return this.id.equals(((Employee) o).id);
		return false;
	}

	// override hashCode to maintain the contract : Equal objects MUST produce the
	// same hashcode
	@Override
	public int hashCode() {
		System.out.println("in hashCode");
		// return 20;
		return id.hashCode();
	}

}
