package tester;

import runnable_tasks.CheckBalalnceTask;
import runnable_tasks.UpdaterTask;
import utils.JointAccount;

public class TestSharedResource {

	public static void main(String[] args) throws InterruptedException{
		// create SINGLETON instance of the joint acct
		JointAccount acct=new JointAccount(5000);
		//create tasks --attach thrds --start the thrds
		Thread t1=new Thread(new UpdaterTask(acct), "cust1");
		Thread t2=new Thread(new CheckBalalnceTask(acct),"cust2");
		t1.start();
		t2.start();
		System.out.println("main waiting for child thrds to complete exec");
		t1.join();
		t2.join();
		System.out.println("main over...");

	}

}
