package runnable_tasks;

import utils.JointAccount;

public class CheckBalalnceTask implements Runnable {
	// state : joint account
	private JointAccount jointAccount;

	public CheckBalalnceTask(JointAccount jointAccount) {
		super();
		this.jointAccount = jointAccount;
		System.out.println("task ctor invoked by : " + Thread.currentThread().getName());
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			while (true) {
				double balance = jointAccount.checkBalance();
				if(balance != 5000)
				{
					System.out.println("ERROR!!!!!!!!!!!!!!!!!!!!!!");
					System.exit(-1);
				}
				Thread.sleep(153);
			}
		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + " got exc " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");

	}

}
