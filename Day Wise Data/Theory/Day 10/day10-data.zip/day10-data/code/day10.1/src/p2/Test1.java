package p2;

import java.util.Arrays;
import java.util.List;

public class Test1 {

	public static void main(String[] args) {
		List<Integer> intList=Arrays.asList(10,20,30,40,50,60);		
		//display list elems
		//convention : imperative style of prog
		for(int i :intList)
			System.out.println(i);
		//Iterable i/f : public default void forEach(Consumer<? super T> action)
		//java.util.function.Consumer : Func i/f
		//SAM : public void accept(T o)
		//display all elems of the list : using internal itearation
		intList.forEach(i -> System.out.println(i));

	}

}
