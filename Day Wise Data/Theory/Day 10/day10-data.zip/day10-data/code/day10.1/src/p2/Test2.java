package p2;

import static utils.ShopUtils.populateProductList;

import java.util.List;

import com.shop.core.Product;

public class Test2 {

	public static void main(String[] args) {
		// get populated product list
		List<Product> productList = populateProductList();
		// display product details : forEach
		// Iterable i/f : public default void forEach(Consumer<? super T> action)
		// java.util.function.Consumer : Func i/f
		// SAM : public void accept(T o)
		// display all elems of the list : using internal iteration
		System.out.println("original list");
		productList.forEach(product -> System.out.println(product));
		//apply discount of 10 on all the products n then display the product list
		productList.forEach(p -> p.setPrice(p.getPrice()-10));
		System.out.println("discounted list");
		productList.forEach(product -> System.out.println(product));
		

	}

}
