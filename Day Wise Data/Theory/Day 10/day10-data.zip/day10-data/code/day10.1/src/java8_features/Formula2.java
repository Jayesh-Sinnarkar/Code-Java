package java8_features;

public class Formula2 implements Formula{

	@Override
	public double calculate(double d1, double d2) {
		System.out.println("imple abstract method in another imple class ");
		return d1-d2;
	}
	// can u override inherited def method ? YES

	@Override
	public double sqrt(double a, double b) {
		System.out.println("overriding def method");
		return Math.sqrt(a+b);
	}
}
