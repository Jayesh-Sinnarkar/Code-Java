package p2;
import static utils.ShopUtils.*;

import java.util.Map;

import com.shop.core.Product;
public class Test5 {

	public static void main(String[] args) {
		// get populated product map from shop utils n display the same
		Map<Integer, Product> productMap = populateProductMap(populateProductList());
		//display all prodcust ids n product details :
		//Map : public void forEach(BiConsumer<? super K,? super V> action)
		//SAM public void accept(K k, V v)
		System.out.println("map details");
		productMap.forEach((k,v) -> System.out.println("Id "+k+" : "+v));
	}

}
