package java8_features3;

public interface Formula {
	//public static final : added implicitly by javac
	double PI = 3.1415;
	//public abstract 
	double calculate(double d1,double d2);
	//Can you add a default method imple in the i/f ? YES 
	//public : added implicitly by javac
	default double sqrt(double a,double b) {
		System.out.println("in i/f def method");
		return Math.sqrt(a*b);
	}
	//can u add a static method in i/f , impl keyword added by javac : public
	static void show()
	{
		System.out.println("in i/f static method");
	}
	
}
