package p2;

import java.util.Arrays;

public class Test7 {

	public static void main(String[] args) {
		int[] data= {12,3,4,5,67,-10,34,55,100};
		//Display data in asc order : in 1 java stmt
		Arrays.stream(data) //IntStream : all ints
		.sorted() //IntStream : sorted asc
		.forEach(i -> System.out.println(i));

	}

}
