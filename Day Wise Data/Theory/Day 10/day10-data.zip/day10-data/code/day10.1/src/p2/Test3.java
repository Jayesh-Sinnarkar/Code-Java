package p2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test3 {

	public static void main(String[] args) {
		List<Integer> intList = new ArrayList<>(Arrays.asList(11, 22, 30, 3, 67, 56, 41, 50, 63));
		System.out.println("orig list");
		intList.forEach(i -> System.out.println(i));
		// Objective : remove all even elements form the list n display the list again
		// Collection i/f : default boolean removeIf(Predicate<? super T> filter)
		// java.util.Predicate : func i/f
		// SAM : public boolean test(T o)
		System.out.println("odd numbers list");
		intList.removeIf(i -> i % 2 == 0);
		intList.forEach(i -> System.out.println(i));

	}

}
