package p2;

import static utils.ShopUtils.populateProductList;

import java.util.List;
import java.util.Scanner;

import com.shop.core.Category;
import com.shop.core.Product;

public class Test4 {

	public static void main(String[] args) {
		// get populated product list
		List<Product> productList = populateProductList();
		System.out.println("original list");
		productList.forEach(product -> System.out.println(product));
		// accept the category name from user (scanner)

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter product category");
			Category cat = Category.valueOf(sc.next().toUpperCase());
			// remove all the products of the specified category from the list
			productList.removeIf(p -> p.getProductCategory() == cat);
			System.out.println("list after remove");
			productList.forEach(product -> System.out.println(product));
		}

	}

}
