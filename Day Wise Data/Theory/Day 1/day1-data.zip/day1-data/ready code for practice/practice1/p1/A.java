package p1;
public class A
{
  private int i;
  int j;
  protected int k;
  public int l;
  public A()
  {
   System.out.println("A's state "+i+" "+j+" "+k+" "+l);
  }
}