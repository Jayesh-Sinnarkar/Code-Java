package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

import com.shop.core.Product;

public interface IOUtils {
//add a static method to store product map in a bin file
	static void storeProductDetails(Map<Integer, Product> map, String fileName) throws IOException {
		// create chain of i/o strms
		// Java App --> OOS --> FOS --> bin file
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName))) {
			// serialization
			out.writeObject(map);
		}
	}

	// add a static method to restore product map from a bin file
	@SuppressWarnings("unchecked")
	static Map<Integer, Product> restoreProductDetails(String fileName) throws IOException, ClassNotFoundException {
		// file validations
		// java.io.File : class for file handling utils
		File file = new File(fileName);// create file cls instance to wrap file path n name
		if (file.isFile() && file.canRead()) {
			// create chain of i/o strms for de-ser
			// Java App <--- OIS <---FIS <---- bin file
			try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
				return (Map<Integer, Product>) in.readObject();// de-ser.
			}
		}
		//=> file not found -ret empty map
		return new HashMap<>();
	}
}
