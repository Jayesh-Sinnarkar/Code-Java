package tester;

import java.util.Map;
import java.util.Scanner;

import com.shop.core.Product;

import static utils.IOUtils.restoreProductDetails;

public class TestDeSerialization {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
				System.out.println("Enter file name , to restore the data");
			//restore product details from bin file using de-ser n display the same				
				Map<Integer, Product> productDetails = restoreProductDetails(sc.next());
				System.out.println("Shop contains : ");
				productDetails.forEach((k,v) -> System.out.println(v));
				System.out.println("products restored ");			
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("main over....");

	}

}
