package com.cdac.geometry;

public class Point2D {

	private int x;
	private int y;

	public Point2D(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return "Point2D [x=" + x + ", y=" + y + "]";
	}

	/*
	 * public boolean isEqual(Point2D anotherPoint) { return this.x==anotherPoint.x
	 * && this.y==anotherPoint.y; }
	 */

	@Override
	public boolean equals(Object obj) {
		return this.x == ((Point2D) obj).x && this.y == ((Point2D) obj).y;
	}

}
