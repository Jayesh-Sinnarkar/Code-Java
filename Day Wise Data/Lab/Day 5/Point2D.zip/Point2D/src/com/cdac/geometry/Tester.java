package com.cdac.geometry;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		System.out.println("Size (Int): ");
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();;
		Point2D[] points = new Point2D[size];
		//accept
		for(int i=0;i<size;i++) {
			System.out.println("x,y (Int): ");
			points[i] = new Point2D(scanner.nextInt(),scanner.nextInt());
		}
		//display
		for(Point2D point: points) {
			System.out.println(point);
		}
		
		System.out.println("Index 1,Index 2 (Int): ");
		int index1 = scanner.nextInt();
		int index2 = scanner.nextInt();
		if((index1<size &&index1 >=0) && (index2<size&&index2>=0)) {
			Point2D firstPoint = points[index1];
			Point2D secondPoint = points[index2];
			if(firstPoint.equals(secondPoint)) {
				System.out.println("equals");
			}else {
				//distance
				System.out.println("not equals");
			}
		}else {
			throw new RuntimeException("invalid indexes");
			
		}
		
		
		

	}

}
