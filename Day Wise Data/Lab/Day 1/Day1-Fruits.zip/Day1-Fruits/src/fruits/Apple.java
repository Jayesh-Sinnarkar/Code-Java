package fruits;

public class Apple extends Fruit {

	public Apple(String color, double weight, String name, boolean fresh) {
		super(color, weight, name, fresh);
	}

	@Override
	public String toString() {
		return "Apple [getColor()=" + getColor() + ", getWeight()=" + getWeight() + ", getName()=" + getName() + "]";
	}

	@Override
	public String taste() {
		return "sweet";
	}
	

	
	

}
