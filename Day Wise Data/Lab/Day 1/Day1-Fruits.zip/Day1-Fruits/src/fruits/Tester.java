package fruits;

public class Tester {
	public static void main(String[] args) {
		Fruit f = new Apple("red",0.3,"apple",true);
		System.out.println(f);
	}
}
