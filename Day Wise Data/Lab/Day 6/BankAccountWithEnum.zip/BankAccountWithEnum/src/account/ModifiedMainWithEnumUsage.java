package account;

import java.util.Scanner;

public class ModifiedMainWithEnumUsage {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Max Accounts: ");
		int maxAccounts = sc.nextInt();// user
		BankAccountWithEnum[] accounts = new BankAccountWithEnum[maxAccounts];
		int bankAcctCreatedCount = 0;
		try {
			while (true) {

				System.out.println("Enter Choice: 1. Create 2. Withdraw 3. Display");
				int choice = sc.nextInt(); // user
				switch (choice) {
				case 1:
					if (bankAcctCreatedCount < maxAccounts) {
						System.out.println("Please enter type of account:");
						BankAccountWithEnum.AccountType acctType = BankAccountWithEnum.AccountType.valueOf(sc.next());
						// modify to take from user
						System.out.println("Please enter accNumber:Balance:FirstName");
						accounts[bankAcctCreatedCount] = new BankAccountWithEnum(sc.nextInt(), sc.nextDouble(), acctType, sc.next()); 
						bankAcctCreatedCount = bankAcctCreatedCount + 1;
					} else
						throw new RuntimeException("maxAccounts reached:");
					break;
				case 2:
					System.out.println("Enter bal to withdraw: ");
					int withdrawBal = sc.nextInt(); // user
					System.out.println("Enter acct number to withdraw: ");
					long acctNumber = sc.nextLong(); // user
					if (!UtilityRulesValidation.checkNegativeBalance(withdrawBal)) {
						BankAccountWithEnum withdrawAccount = new BankAccountWithEnum(acctNumber);
						boolean validAcct = false;
						int i = 0;
						for (BankAccountWithEnum ba : accounts) {
							if (i < bankAcctCreatedCount) {
								if (ba.equals(withdrawAccount)) {
									ba.withdraw(withdrawBal);
									validAcct = true;
									break;
								}
							} else {
								break;
							}
							i++;
						}
						if (!validAcct) {
							throw new RuntimeException("AccountNumber or Withdrawal Balance not right:");
						}
					}

					else
						throw new RuntimeException("negative balance:");
					break;
				case 3:
					int i = 0;
					for (BankAccountWithEnum ba : accounts) {
						if (i < bankAcctCreatedCount) {
							System.out.println(ba);
						} else {
							break;
						}
						i++;
					}
					break;
				default:
					System.exit(0);
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
