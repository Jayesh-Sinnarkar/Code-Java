package account;

public class BankAccountWithEnum implements Comparable<BankAccountWithEnum> {

	private Long accountNumber;// object reference
	private Double balance;
	private BankAccountWithEnum.AccountType acctType;
	private String firstName;

	public BankAccountWithEnum(long accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}

	public BankAccountWithEnum(long accountNumber, double balance, BankAccountWithEnum.AccountType acctType,
			String firstName) throws InvalidAccountDetailsException {

		if (!UtilityRulesValidation.checkBalance(balance, acctType))
			throw new InvalidAccountDetailsException("Invalid Balance: ");
		
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.acctType = acctType;
		this.firstName = firstName;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public BankAccountWithEnum.AccountType getAcctType() {
		return acctType;
	}

	public void setAcctType(BankAccountWithEnum.AccountType acctType) {
		this.acctType = acctType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "BankAccountWithEnum [accountNumber=" + accountNumber + ", balance=" + balance + ", acctType=" + acctType
				+ ", firstName=" + firstName + "]";
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		 
		BankAccountWithEnum other = (BankAccountWithEnum) obj;
		return accountNumber.equals(other.accountNumber);
	}

	public void withdraw(int withdrawBal) {
		double tempBal = this.balance - withdrawBal;
		if (UtilityRulesValidation.checkBalance(tempBal, this.acctType)) {
			this.balance = tempBal;
		} else {
			//throw exception
			System.out.println("cannot withdraw: min balance needs to be maintained");
		}
	}

	@Override
	public int compareTo(BankAccountWithEnum o) {
		return this.accountNumber.compareTo(o.accountNumber);
	}

	public enum AccountType {
		SAVING(1000), LOAN(100), FD(500), CURRENT(800);

		private int minBalance;

		private AccountType(int value) {
			this.minBalance = value;
		}

		public int getMinBalance() {
			return minBalance;
		}

	}
}
