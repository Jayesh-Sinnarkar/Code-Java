package account;

public class InvalidAccountDetailsException extends Exception {

	public InvalidAccountDetailsException(String message) {
		super(message);
	}
}
