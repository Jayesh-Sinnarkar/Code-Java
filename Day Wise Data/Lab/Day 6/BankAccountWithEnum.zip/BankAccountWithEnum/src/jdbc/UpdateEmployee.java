package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateEmployee {
	public static void main(String[] args) {
		try {
			Connection conn = DbUtils.getConnection();
			String sql = "update emp set emp_name=? where emp_id=? ";
			PreparedStatement pst =  conn.prepareStatement(sql);
			
			pst.setString(1, "jitesh");
			pst.setInt(2, 1);
			System.out.println(pst.executeUpdate());;		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
