DROP PROCEDURE IF EXISTS get_emp_details;

DELIMITER $$
CREATE PROCEDURE get_emp_details(IN emp_id INT)
BEGIN
	SELECT emp_id,emp_name 
	FROM emp
	WHERE emp.emp_id = emp_id;
    END$$
DELIMITER ;

call get_emp_details(1);