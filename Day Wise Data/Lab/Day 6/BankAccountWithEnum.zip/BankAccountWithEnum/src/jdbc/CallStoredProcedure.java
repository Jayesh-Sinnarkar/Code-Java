package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallStoredProcedure {
	public static void main(String[] args) {
		try {
			Connection conn = DbUtils.getConnection();

			String query = "{CALL get_emp_details(?)}";
			CallableStatement callStmt = conn.prepareCall(query);

			callStmt.setInt(1, 4);
			ResultSet rs = callStmt.executeQuery();

			while (rs.next()) {
				System.out.println(rs.getInt("emp_id") + " " + rs.getString("emp_name"));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
