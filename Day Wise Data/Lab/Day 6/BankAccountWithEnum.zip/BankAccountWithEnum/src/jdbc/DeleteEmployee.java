package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteEmployee {
	public static void main(String[] args) {
		try {
			Connection conn = DbUtils.getConnection();
			String sql = "delete from emp where emp_id=? ";
			PreparedStatement pst =  conn.prepareStatement(sql);
			
			pst.setInt(1, 6);
			System.out.println(pst.executeUpdate());;		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
