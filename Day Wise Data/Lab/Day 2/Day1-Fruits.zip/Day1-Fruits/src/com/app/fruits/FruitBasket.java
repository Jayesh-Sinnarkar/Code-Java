package com.app.fruits;

import java.util.Scanner;

public class FruitBasket {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		Fruit[] fruits = new Fruit[size];

		fruits[0] = new Apple("Red", 0.25, "Apple", true);
		fruits[1] = new Orange("Orange", 0.25, "Orange", true);

		for (Fruit f : fruits) {
			if (f != null) {
				System.out.println(f + " " + f.taste());
				if (f.taste().contains("sour"))
					f.setFresh(false);

				if (f instanceof Apple) {
					((Apple) f).jam();
					System.out.println(f.isFresh());
				} else if (f instanceof Orange) {
					((Orange) f).juice();
					System.out.println(f.isFresh());
				}
			}
		}

	}
}
