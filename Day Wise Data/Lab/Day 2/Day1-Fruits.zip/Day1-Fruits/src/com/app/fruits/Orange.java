package com.app.fruits;

public class Orange extends Fruit {

	public Orange(String color, double weight, String name, boolean fresh) {
		super(color, weight, name, fresh);
	}
	
	/*
	 * @Override public String toString() { return "Orange [getColor()=" +
	 * getColor() + ", getWeight()=" + getWeight() + ", getName()=" + getName() +
	 * "]"; }
	 */

	@Override
	public String taste() {
		return "sour";
	}
	
	public void juice() {
		System.out.println("Orange - juice");
	}

}
