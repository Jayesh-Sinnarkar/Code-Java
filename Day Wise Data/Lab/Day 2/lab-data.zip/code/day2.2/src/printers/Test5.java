package printers;

public class Test5 {

	public static void main(String[] args) {
		int[] data= {1,2,3,4,6};
		System.out.println("Name of the array class "+data.getClass());//[I
		String[] names= {"Rama","Riya","Shubham"};
		System.out.println("Name of the array  class "+names.getClass());//[Ljava.lang.String;

	}

}
