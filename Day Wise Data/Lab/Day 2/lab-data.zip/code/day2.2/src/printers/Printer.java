package printers;

public interface Printer {
	// impl keywords added by javac : public static final
	int SPEED = 100;

//impl keywords added by javac : public abstract
	void print(String message);
}
