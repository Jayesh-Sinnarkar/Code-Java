package exception_handling;

public class Test2 {

	public static void main(String[] args) {
		System.out.println("The parsed number " + Integer.parseInt("a12345bc"));// NumberFormatExc
		System.out.println("main over...");
	}

}
